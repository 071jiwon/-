//
//  Model.swift
//  Heyum_DBD
//
//  Created by 김정현 on 2020/08/18.
//  Copyright © 2020 SWU_Hyeum. All rights reserved.
//

//import Foundation
//
//class Keyword
//{
//    var content: String //내용 저장
//    
//    init(content: String) //속성초기화
//    {
//        self.content = content
//    }
//    
//    //테이블뷰에 표시할 더미 데이터
//    static var KeywordList =
//    [
//        Keyword(content: "날씨"),
//        Keyword(content: "소나기"),
//        Keyword(content: "물방울"),
//        Keyword(content: "별똥별"),
//        Keyword(content: "구름"),
//        
//        Keyword(content: "태양"),
//        Keyword(content: "노을"),
//        Keyword(content: "아침햇살"),
//        Keyword(content: "저녁"),
//        Keyword(content: "공백"),
//        
//        Keyword(content: "터널"),
//        Keyword(content: "건널목"),
//        Keyword(content: "징검다리"),
//        Keyword(content: "신호등"),
//        Keyword(content: "광복"),
//        
//        Keyword(content: "웃는 얼굴"),
//        Keyword(content: "불면증"),
//        Keyword(content: "베개"),
//        Keyword(content: "이불"),
//        Keyword(content: "필름"),
//        
//        Keyword(content: "여행"),
//        Keyword(content: "숲"),
//        Keyword(content: "매미"),
//        Keyword(content: "거미"),
//        Keyword(content: "고래"),
//        
//        Keyword(content: "각설탕"),
//        Keyword(content: "홍차"),
//        Keyword(content: "탄산"),
//        Keyword(content: "빙수"),
//        Keyword(content: "감기약"),
//        Keyword(content: "거울"),
//        Keyword(content: "자갈돌")
//    ]
//    //테이블뷰에 표시할 더미 데이터
//}
