import UIKit

let keyword = ["ㄴㅏㄱㅅㅓ", "ㅂㅏㄷㅏ", "ㄱㅣㅂㅜㄴ", "ㄴㅏㄹㅆㅣ"]
let QnA = ["dhsmf dkcadms anjduTdj?", "chlrms rkwkd woalTdjTejs dlf?"]

let rkw = keyword.randomElement()!
let rqa = QnA.randomElement()!

var date = Date()
var format = DateFormatter()
format.dateFormat = "yyyyㄴㅕㄴ MMㅇㅜㅓㄹ ddㅇㅣㄹ"
var today_date = format.string(from: Date())

class ViewController: UIViewController {
    @IBOutlet var todate: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        todate.text = today_date
    }
    @IBOutlet weak var gongback: UILabel!
    @IBAction func word(_sender: Any){
        if gongback == nil{ 
        gongback.text = rkw
        }
        
}
    @IBOutlet weak var nonque: UILabel!
    @IBAction func que(_sender: Any){
        if nonque == nil {
        nonque.text = rqa
        }
    }
    
}



